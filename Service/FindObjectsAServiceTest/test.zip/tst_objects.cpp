#include <QtTest>
#include <QCoreApplication>

// add necessary includes here

class Objects : public QObject
{
    Q_OBJECT

public:
    Objects();
    ~Objects();

private slots:
    void initTestCase();
    void cleanupTestCase();
    void test_case1();

};

Objects::Objects()
{

}

Objects::~Objects()
{

}

void Objects::initTestCase()
{

}

void Objects::cleanupTestCase()
{

}

void Objects::test_case1()
{

}

QTEST_MAIN(Objects)

#include "tst_objects.moc"
